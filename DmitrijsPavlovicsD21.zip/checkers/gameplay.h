#ifndef GAMEPLAY_H_INCLUDED
#define GAMEPLAY_H_INCLUDED
#include <iostream>
using namespace std;

void play();



#endif // GAMEPLAY_H_INCLUDED
