#include <iostream>
#include <windows.h>
#include "board.h"
#include "gameplay.h"
#include <string>
#include <conio.h>

using namespace std;


